# techfu.io stack state challenge

## Contents
* this README 
* libs of the project
* jar of the project
* a sample files to test the project

## Getting started
* Your  must be started using a shell script called run.sh that accepts these two
parameters. After the calculation completes, your program should write it's output in the
format shown below.

{
"graph": {
"components": [
{
"id": "app",
"own_state": "clear",
"derived_state": "warning",
"check_states": {
"CPU load": "clear",
"RAM usage": "no_data"
},
"depends_on": [
"db"
]
},
{
"id": "db",
"own_state": "warning",
"derived_state": "warning",
"check_states": {
"CPU load": "warning",
"RAM usage": "no_data"
},
"dependency_of": [
"app"
]
}
]
}
}
