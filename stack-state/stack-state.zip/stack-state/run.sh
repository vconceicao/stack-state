java -jar stack-state.jar $*
